/**
* Program No°1 Figures.
*/
public class figuras{

    public static void main(String [] args){
        //I printed the figures in the terminal with de command "System.out.println()".
        System.out.println("*********      ***        *         *       ");
        System.out.println("*       *    *     *     ***       * *      ");
        System.out.println("*       *   *       *   *****     *   *     ");
        System.out.println("*       *   *       *     *      *     *    ");
        System.out.println("*       *   *       *     *     *       *   ");
        System.out.println("*       *   *       *     *      *     *    ");
        System.out.println("*       *   *       *     *       *   *     ");
        System.out.println("*       *    *     *      *        * *      ");
        System.out.println("*********      ***        *         *       ");
    }
}