/**
*Clase que solicita los datos necesarios para enviar un telegrama
*Alumno: Martinez Monroy Luis Alberto
*Laboratorio ICC 2017-1
*N°cuenta: 314212391
*/

import java.util.Scanner;

public class Telegrama{

	public static void main(String args[]){
		Scanner leer  = new Scanner(System.in);
		String nombreremit = "";
		String nombredest = "";
		String prof1 = "";
		String prof2 = "";
		String direccion1 = "";
		String mensaje = "";



		

		System.out.println("Escriba el nombre del remitente ");
		nombreremit = leer.nextLine();

		System.out.println("¿cual es la profesion del remitente?");
		prof1 = leer.nextLine();

		System.out.println("Escriba el nombre del destinatario ");
		nombredest = leer.nextLine();

		System.out.println("¿cual es la profesion del destinatario?");
		prof2 = leer.nextLine();

		System.out.println("Escriba la direccion del destinatario");
		direccion1 = leer.nextLine();

		System.out.println("Escriba su mensaje ");
		mensaje = leer.nextLine();

		System.out.println("Nombre del remitente:" + nombreremit);
		System.out.println("Profesion del remitente:" + prof1);
        System.out.println("nombre del destinatario:" + nombredest);
        System.out.println("profesion del destinatario:" + prof2);
        System.out.println("Dirección del destinatario:" + direccion1);
        System.out.println("Mensaje:" + mensaje);

        System.out.println("***Telegrama***");
        String var0 = prof1.substring(1, 3);
        String var1 = var0.toLowerCase();
        String var2 = prof1.substring(0, 1);
        String var3 = var2.toUpperCase();
        String var9;
        
        var9 = var3 + var1;

        



		System.out.println("De:" + var9 + ". "+ nombreremit.toUpperCase());

		String var4 = prof2.substring(1, 3);
        String var5 = var4.toLowerCase();
        String var6 = prof2.substring(0, 1);
        String var7 = var6.toUpperCase();
        String aux2;
        String var8;

         var8 = var7 + var5;

		System.out.println("Para:" + var8+ ". " + nombredest.toUpperCase());
		System.out.println("Mensaje:");
		System.out.println( "necesario"+ mensaje.substring(7) );





		int nupalabras = mensaje.length();
		int costoletra = 3;
		int costototal;

		costototal = costoletra * nupalabras;

		System.out.println("Costo: $" + costototal);

		System.out.println(nupalabras + "letras." + " Costo por letra $3.00");

		System.out.println("Dirección:");
		//int tam1 = direccion1.length();
		//int vard1 = direccion1.indexOf(".");
		//String direccion2 = direccion1.substring(0,vard1);
		//System.out.print(direccion2);

		//int vard2 = direccion1.indexOf(". ");
		
		//String direccion3 = direccion1.substring(vard1+1, vard2);
		//System.out.println(" "+ direccion3);
		

		//int vard3 = direccion1.indexOf(" ");
		//int vard4 = direccion1.indexOf(",");
		//String direccion4 = direccion1.substring(vard3+1, vard4); 
		//System.out.println(direccion4);
		//int tam = direccion1.length();
		//String direccion5 = direccion1.substring(, tam);
		int tamd1 = direccion1.length();
		int vard1 = direccion1.indexOf(".");
		String dir1 = direccion1.substring(0,vard1);
		System.out.print(dir1);
		String part1= direccion1.substring(vard1+1, tamd1);
		
		int tamd2 = part1.length();
		int vard2 = part1.indexOf(".");
		String dir2 = part1.substring(0, vard2);
		System.out.println(" "+ dir2);
		String part2 = part1.substring(vard2+1, tamd2);

		int tamd3 = part2.length();
		int vard3 = part2.indexOf(".");
		String dir3 = part2.substring(0, vard3);
		System.out.println(dir3);
		String part3 = part2.substring(vard3+1, tamd3);

		System.out.println(part3);

		


	}
}
