/**
 * Programa que pide al usuario que teclee una palabra e indica
 * si la palabra tecleada es palindromo o no.
 *@author Martinez Monroy Luis Alberto
 */
import java.util.Scanner;

public class Palindromo {

  public static void main(String[] args) {
    Scanner lector = new Scanner(System.in);
    System.out.println("Introduce una palabra:");//pide al usuario una cadena
    String palabra = lector.nextLine();// lee la cadena escrita por el usuario
    int inc = 0;
    int fin = palabra.length()-1;
    boolean falso = false;

    while((inc<fin) && (!falso)){
    		if (palabra.charAt(inc)==palabra.charAt(fin)){				
			inc++;
			fin--;
		} else {
			falso = true;
		}
    }

    if(!falso){
    	System.out.println(palabra +" Es un palindromo");
    }
    else{
    	System.out.println(palabra + " No es un palindromo");
    }

    lector.close();// cerramos el lector para no dañar los archivos
  }
}
