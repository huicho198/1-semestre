/**
 * Programa que cuenta la cantidad de numeros pares tecleados por el usuario.
 * @author Martinez Monroy Luis Alberto
 */

import java.util.Scanner;

public class Pares {

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);// se crea el objeto sc
    int pares = 0, nones = 0, cantidad;//declaramos en el mismo renglon los numeros
    int contador=0;//separamos el contador para no confundirnos
    int a = 0; 

    do {
              System.out.println("Introduce un entero mayor a 0");
              System.out.println("El programa parara hasta que ingreses un numero  igual a 0");
                 a = sc.nextInt();
                while(a!=0){
                    if(a%2 == 0){
                        pares += 1;
                        contador += 1;
                    }
                    else{
                        nones += 1;
                        contador +=1;
                    }
                    System.out.println("Introduce un entero mayor a 0");
                     a = sc.nextInt();
                 } 

    }while(a != 0);
    
    System.out.println("En total tecleaste: " + (contador) + " numeros");//imprimimos el contador de numeros que ya tecleamos
    
    System.out.println(pares + " Numeros Pares");//les damos la referencia de numeros pares e impares
    
    System.out.println(nones + " Numeros Nones");
    
    sc.close();//cerramos el scaner para no dañar archivos
  }
}
