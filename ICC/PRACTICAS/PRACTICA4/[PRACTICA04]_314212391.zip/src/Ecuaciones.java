/**
* Alumno: Martinez Monroy Luis Alberto
* N° Cuenta: 314212391
* Programa que calcula las soluciones de un sistema de ecuaciones lineales 2x2
* Ejercicio 1
*/
public class Ecuaciones {

  public static void main(String[] args) {
    double a = 5, b = 2, c = 7;
    double d = 10, e = 4, f = 14;
    double determinante, x, y;
    double divisor, dividendox, dividendoy;
    divisor = (a*e)-(b*d);
    dividendox= (c*e)-(b*f);
    dividendoy= (a*f)-(c*d);

    x=dividendox/divisor;
    y= dividendoy/divisor; 
      

    if(divisor==0){
      
       System.out.println("El sistema no tiene solución unica");
    }
   else{    
    System.out.println("El valor de X es: " +x);
    System.out.println("El valor de Y es: "+y);
   }
  }
}
