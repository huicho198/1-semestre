/*
* Alumno: Martinez Monroy Luis Alberto
* N° de cuenta: 314212391
* Ejercicio 4
*/
import java.util.Scanner;
import java.util.Random;
public class random{
	public static void main(String[] args){
		Random  rnd = new Random();
		Scanner scan = new Scanner(System.in);
		int numero = (int)(rnd.nextDouble() * 11 + 1);
		int resultado, resultado2, resultado3;
		System.out.println("ADIVINA UN NUMERO ALEATORIO ENTRE 10 Y 1");
		System.out.println("**Tienes 3 intentos**");
		System.out.println("1° Intento");
		resultado = scan.nextInt();
		if(resultado==numero){
			System.out.println("Felicidades, le atinaste!!!");

		}
		else{
			if(resultado>numero){
				System.out.println("Upss, no te atinaste, intentalo de nuevo");
				System.out.println("El numero es menor a tu resultado");
				System.out.println("2° intento");
				resultado2 = scan.nextInt();
				if(resultado2==numero){
					System.out.println("Felicidades, le atinaste!!!");
				}
					else{
						if(resultado2>numero){
							System.out.println("Upss, no te atinaste, intentalo de nuevo");
						System.out.println("El numero es menor a tu resultado");
						System.out.println("ultimo intento");
						resultado3 = scan.nextInt();
						if(resultado3==numero){
							System.out.println("Felicidades, le atinaste!!!");
						}
						else{
							System.out.println("Lastima, perdiste las 3 oportunidades, el numero era: "+ numero);
						}
						}
							else{
								System.out.println("Upss, no te atinaste, intentalo de nuevo");
								System.out.println("El numero es mayor a tu resultado");
								System.out.println("ultimo intento");
								resultado3 = scan.nextInt();
								if(resultado3==numero){
									System.out.println("Felicidades, le atinaste!!!");
								}
								else{
									System.out.println("Lastima, perdiste las 3 oportunidades, el numero era: "+ numero);
								}
							}
					}
			}
				else{
					System.out.println("Upss, no te atinaste, intentalo de nuevo");
				System.out.println("El numero es mayor a tu resultado");
				System.out.println("2° intento");
				resultado2 = scan.nextInt();
				if(resultado2== numero){
					System.out.println("Felicidades, le atinaste!!!");
				}
				else{
					if(resultado2>numero){
						System.out.println("Upss, no te atinaste, intentalo de nuevo");
						System.out.println("El numero es menor a tu resultado");
						System.out.println("ultimo intento");
						resultado3 = scan.nextInt();
						if(resultado3== numero){
							System.out.println("Felicidades, le atinaste!!!");
						}
							else{
								System.out.println("Lastima, perdiste las 3 oportunidades, el numero era: "+ numero);
							}
					}
						else{
							System.out.println("Upss, no te atinaste, intentalo de nuevo");
							System.out.println("El numero es mayor a tu resultado");
							System.out.println("ultimo intento");
							resultado3 = scan.nextInt();
							if(resultado3==numero){
								System.out.println("Felicidades, le atinaste!!!");
							}
								else{
									System.out.println("Lastima, perdiste las 3 oportunidades, el numero era: "+ numero);
								}
						}
				}




				}
		}
	}
}
