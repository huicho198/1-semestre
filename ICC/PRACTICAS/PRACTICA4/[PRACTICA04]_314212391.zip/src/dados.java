/*
*Alumno: Martinez Monroy Luis Alberto
*N° Cuenta: 314212391
*Ejercicio 3
*/

import java.util.Random;
public class dados {
 	public	static void main(String[] args){
 		Random  rnd = new Random();
 		 int dado1 = (int)(rnd.nextDouble() * 6 + 1);
 		 int dado2 = (int)(rnd.nextDouble() * 6 + 1);
 		 int suma = dado1 + dado2;
 		 if(suma == 7 || suma == 11){
 		 	System.out.println("GANASTE!!!!, tuviste "+ suma);
 		 }
 		 else{
 		 	if(suma == 2 || suma == 3 || suma == 12){
				System.out.println("Perdiste jajaja!! sacaste "+ suma);
 		 	}
 		 	else{
 		 		int dado3 = (int)(rnd.nextDouble() * 7 + 1);
				int dado4 = (int)(rnd.nextDouble() * 7 + 1);
 		 		int suma2 = dado3 + dado4;

 		 		System.out.println("Tienes que sacar "+ suma +" otra vez para ganar");
 		 		if(suma2 == suma){
 		 		System.out.println("Ganaste volviste a tener la misma suma de caras");
 		 	 }
 		 	 	else{
 		 	 		System.out.println("Perdiste jajaja, tu resultado fue "+ suma2);
 		 	 	}
 		 	}
 		 }



 	}




}
