/*
*Alumno: Martinez Monroy Luis Alberto
*N° Cuenta: 314212391
*Ejercicio 3 pero con Case
*/

import java.util.Random;
public class dadoscase{
	public static void main(String[] args) {
		Random  rnd = new Random();
 		 int dado1 = (int)(rnd.nextDouble() * 6 + 1);
 		 int dado2 = (int)(rnd.nextDouble() * 6 + 1);
 		 int suma = dado1 + dado2;
 		 		int dado3 = (int)(rnd.nextDouble() * 7 + 1);
				int dado4 = (int)(rnd.nextDouble() * 7 + 1);
 		 		int suma2 = dado3 + dado4;

 		 switch(suma){
 		 	case 7:
 		 		System.out.println("GANASTE!!!!, tuviste "+ suma);
 		 	break;
 		 	case 11:
 		 		System.out.println("GANASTE!!!!, tuviste "+ suma);
 		 	break;
 		 	case 2:
 		 		System.out.println("Perdiste jajaja!! sacaste "+ suma);
 		 	break;
 		 	case 3:
 		 		System.out.println("Perdiste jajaja!! sacaste "+ suma);
 		 	break;
 		 	case 12:
 		 		System.out.println("Perdiste jajaja!! sacaste "+ suma);
 		 	break;
 		 	case 4:
 		 		System.out.println("Tienes que sacar "+ suma +" otra vez para ganar");
 		 		if(suma2 == suma){
 		 		System.out.println("Ganaste volviste a tener la misma suma de caras");
 		 	 }
 		 	 	else{
 		 	 		System.out.println("Perdiste jajaja, tu resultado fue "+ suma2);
 		 	 	}
 		 	break;
 		 	case 5:
 		 		System.out.println("Tienes que sacar "+ suma +" otra vez para ganar");
 		 		if(suma2 == suma){
 		 		System.out.println("Ganaste volviste a tener la misma suma de caras");
 		 	 }
 		 	 	else{
 		 	 		System.out.println("Perdiste jajaja, tu resultado fue "+ suma2);
 		 	 	}
 		 	break;
 		 	case 6:
 		 		System.out.println("Tienes que sacar "+ suma +" otra vez para ganar");
 		 		if(suma2 == suma){
 		 		System.out.println("Ganaste volviste a tener la misma suma de caras");
 		 	 }
 		 	 	else{
 		 	 		System.out.println("Perdiste jajaja, tu resultado fue "+ suma2);
 		 	 	}
 		 	break;
 		 	case 8:
 		 		System.out.println("Tienes que sacar "+ suma +" otra vez para ganar");
 		 		if(suma2 == suma){
 		 		System.out.println("Ganaste volviste a tener la misma suma de caras");
 		 	 }
 		 	 	else{
 		 	 		System.out.println("Perdiste jajaja, tu resultado fue "+ suma2);
 		 	 	}
 		 	break;
 		 	case 9:
 		 		System.out.println("Tienes que sacar "+ suma +" otra vez para ganar");
 		 		if(suma2 == suma){
 		 		System.out.println("Ganaste volviste a tener la misma suma de caras");
 		 	 }
 		 	 	else{
 		 	 		System.out.println("Perdiste jajaja, tu resultado fue "+ suma2);
 		 	 	}
 		 	break;
 		 	case 10:
 		 		System.out.println("Tienes que sacar "+ suma +" otra vez para ganar");
 		 		if(suma2 == suma){
 		 		System.out.println("Ganaste volviste a tener la misma suma de caras");
 		 	 }
 		 	 	else{
 		 	 		System.out.println("Perdiste jajaja, tu resultado fue "+ suma2);
 		 	 	}
 		 	break;
 		 }
 		 

	}
}

