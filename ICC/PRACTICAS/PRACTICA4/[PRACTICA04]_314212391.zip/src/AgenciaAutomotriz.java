/**
* Alumno: Martinez Monroy Luis Alberto
* N° Cuenta: 314212391
* Ejercicio 2
* Programa que muestra el enganche y las mensualidades a pagar
* para un automovil.
*/
import java.util.Scanner;

public class AgenciaAutomotriz {

  public static void main(String[] args) {
    double costo, x, y, z;
    Scanner precio = new Scanner(System.in);
    
    
    System.out.println("¿Cuál es el precio del automovil?");
    costo = precio.nextDouble();
    
    	if(costo > 250000){
    		x= 35;
    		y= costo * (.35);
    		z=(costo-y)/ 36;
    		System.out.println("\nSu enganche debe de ser de"+x+"%\n" + "\nEl cual seria de: " + y + "\n\nEl resto debe cubrirse en 36 mensuelidades de: " + z + "\n");
			}
			else{
					if(costo <= 250000 && costo >= 150000){ 
					x= 25;
					y= costo * (.25);
					z= (costo-y)/24;	
					System.out.println("\nSu enganche debe de ser de"+x+"%\n" + "\nEl cual seria de: " + y + "\n\nEl resto debe cubrirse en 24|	 mensuelidades de: " + z + "\n");
					}
					else{
					x= 15;
					y= costo * (.15);
					z= (costo-y)/18;	
					System.out.println("\nSu enganche debe de ser de"+x+"%\n" + "\nEl cual seria de: " + y + "\n\nEl resto debe cubrirse en 24 mensuelidades de: " + z + "\n");
						}
			
				}

  }
}
