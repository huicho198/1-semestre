/*
*Alumno: Martinez Monroy Luis Alberto
*N° Cuenta: 314212391
*Ejercicio 5
*/
import java.util.Scanner;
import java.util.Random;
public class ppt{
	public static void main(String[] args){
		Scanner scan = new Scanner(System.in);
		Random rnd = new Random();
		int usuario;
		int computadora = (int)(rnd.nextDouble() * 3 + 1);
		System.out.println("***Juguemos Piedra, Papel o Tijera***");
		System.out.println("1.-Piedra");
		System.out.println("2.-Papel");
		System.out.println("3.-Tijera");
		System.out.println("**digita el numero de la opcion deseada**");
		usuario = scan.nextInt();

		if(usuario==computadora){
			System.out.println("Quedan empate, yo escogi: "+ computadora);
		}
		else{
			if(usuario==1 && computadora==3){
				System.out.println("Ganaste!!!, yo escogi:" + computadora);
			}
				else{
					if(usuario==1 && computadora==2){
						System.out.println("Perdiste jajaja, yo escogi: "+ computadora);
					}
						else{
							if(usuario==2 && computadora==1){
							System.out.println("Ganaste!!!, yo escogi: "+ computadora);	
						}
						else{
							if(usuario==2 && computadora==3){
								System.out.println("Perdiste jajaja, yo escogi: "+ computadora);
							}
							else{
								if(usuario==3 && computadora==2){
									System.out.println("Ganaste!!!, yo escogi:"+ computadora);
								}
								else{
									if(usuario==3 && computadora==1){
										System.out.println("Perdiste jajaja, yo escogi; "+ computadora);
									}
								}
							}
						}
				}
		}




	}
}
}