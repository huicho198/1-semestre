﻿Alumno: Luis Alberto Martinez Monroy
N° Cuenta: 314212391
Correo: luis_martinez98@ciencias.unam.mx


Cuestionario
1.¿Qué errores encontraste al compilar la práctica?
Errores de sintaxis dentro del documento Cadenas, principalemente unas omiciones para caracteres especiales
2. Los errores que encontraste.¿Qué tipo de error son, sintácticos o semánticos? Justifica.
Fueron errores de Sintácticos debiado a que el mismo compilador nos mostraba los errores por falta de ; o uso de caracteres especiales.

3. ¿Cuál es la diferencia entre System.out.println y System.out.print?
System.out.printl imprime con salto de linea y System.out.print imprime sin salto de linea

4. Explica la causa de que la siguiente línea de código marque error de compilación.
System.out.println(“Edificio “Rosales”, Int, #15”);
En la linea de codigo se estan usando caracteres especiales las cuales serian (“ ”), sin embargo, habira que meter \” \” para utilizarlos dentro de de nuestra cadena de caracteres. La cual quedaria terminada de manera.

System.out.println(“Edificio \”Rosales\”, Int, #15”);

