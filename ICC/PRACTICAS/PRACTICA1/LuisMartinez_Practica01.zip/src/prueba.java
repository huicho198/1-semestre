/** 
 * Clase de prueba para la practica 01
 *@autor Luis Alberto Martinez
 *@version 0.1
 */

public class prueba { /** es una clase publica */
    public static void main(String [] args){   /**Es el metodo del programa */
	System.out.println("Hola que onda");/**Imprime con salto de linea */
	    System.out.print("hola que onda"); /**Imprime sin salto de linea */
/** \t es para tabular dentro de la impresion de pantalla  */
    }
}
