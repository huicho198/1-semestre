/**
*Programa que contiene ejemplos de cadenas y los datos del usuario
*@author Luis Eduardo Miranda S&aacutenchez
*@version 0.1*/
public class Datos{
	
	public static void main(String[] args) {
		
		System.out.println("\nSoy Luis Alberto Martinez Monroy");
		System.out.println("Me llaman: \"Huicho\"");
		System.out.print("Tengo la edad de: ");
		System.out.println("17");
		System.out.print("Curse el bachillerato en: "+ "\nEscuela Nacional Preparatoria");
		System.out.print("No. 6 \"Antonio Caso\"\n\n");
		
	}
}
