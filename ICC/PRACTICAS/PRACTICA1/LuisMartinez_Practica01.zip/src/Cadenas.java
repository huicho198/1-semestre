/**
*Programa que contiene ejemplos de cadenas
*@author Luis Eduardo Miranda S&aacutenchez
*@version 0.1
*/
public class Cadenas{
	
	public static void main(String[] args) {
		
		System.out.println("!!Muchas Felicidades Napoleon¡¡");
		
		System.out.println("Te deseo lo mejor en este tu cumpleaños");
		System.out.println("Quisiera poder darte un fuerte abrazo \\(o-o)/ \\ pero soy solo un mensaje.");
		
		System.out.println("Pero bueno...");

		System.out.println("De Verdad \"!!Muchas Felicidades¡¡\" ");

		System.out.println("Salúdame a todos por allá");

		System.out.println("Pásala bien.");
	}
}
