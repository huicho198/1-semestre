/**
*Programa para probar la clase Alumno
*@author Mart&iaccute;nez Monroy Luis Alberto
*N° Cuenta = 314212391
*@version 2.0
*/
public class MainAlumno{
	


	public static void main(String[] args) {
		Alumno alumno_prueba = new Alumno();
		Alumno alumno2 = new Alumno("309199814","Daniel","Lopez","Rodriguez",
			"mail@mail.com", "17", "fisica", "hombre", "123513513", "111298");

				//System.out.println (alumno_prueba);
				//System.out.println(alumno2);

				//System.out.println(alumno_prueba.getNombre());
				//System.out.println(alumno2.getNombre());

				//System.out.println(alumno_prueba.getNumCuenta());
				//System.out.println(alumno2.getNumCuenta());

				//System.out.println(alumno_prueba.getApellido_p());
				//System.out.println(alumno2.getApellido_p());

				//System.out.println(alumno_prueba.getApellido_m());
				//System.out.println(alumno2.getApellido_m());

				//System.out.println(alumno_prueba.getCorreo());
				//System.out.println(alumno2.getCorreo());

				//System.out.println(alumno_prueba.getEdad());
				//System.out.println(alumno2.getEdad());

				//System.out.println(alumno_prueba.getCarrera());
				//System.out.println(alumno2.getCarrera());

				//System.out.println(alumno_prueba.getSexo());
				//System.out.println(alumno2.getSexo());

				//System.out.println(alumno_prueba.getTelefono());
				//System.out.println(alumno2.getTelefono());

				//System.out.println(alumno_prueba.getFecha_nac());
				//System.out.println(alumno2.getFecha_nac());

				//String curp = alumno2.curp(alumno2);
				//System.out.println("Tu Curp es :"+ curp);

				//boolean ccc = alumno2.resultado(alumno2.getCarrera());
				//System.out.println("Estudias actualmente la carrera de computacion : "+ ccc);
				
				/**
				*Es la comprobacion de que si sirve mi m&eacute;todo para calcular la edad apartir de la fecha de nacimiento del alumno
				*/
				String result = alumno2.CalcuEdad(alumno2);
				System.out.println("La edad del alumno es :"+ result);

		
 }
}