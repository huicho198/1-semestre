/**
*Clase Alumno con las funciones necesarias para poder crear e identificar un alumno
*N° cuenta 314212391
*@author Luis Alberto Martinez Monroy
*Materia: Introduccion a la Ciencias de la Computac&iacute;on
*@version 2.0
*/
import java.util.*;
public class Alumno{
	
	private String numCuenta = "";
	private String nombre = "";
	private String apellido_m= "";
	private String apellido_p= "";
	private String correo = "";
	private String edad = "";
	private String carrera ="";
	private String sexo = "";
	private String telefono = "";
	private String fecha_nac= "";

	
	/**
	*Constructor por omisi&oacute;n
	*asignando como parametros mis datos;
	*/
	public Alumno(){
	this.numCuenta = "314212391";
	this.nombre = "Luis Alberto";
	this.apellido_p= "Martinez";
	this.apellido_m= "Monroy";
	this.correo= "luis_martinez98@ciencias.unam.mx";
	this.edad= "17";
	this.carrera = "ciencias de la computacion";
	this.sexo= "hombre";
	this.telefono= "5554947153";
	this.fecha_nac="111298";

	}

	/**
	*Constructor de un alumno
	*@param numCuenta String: N&uacute;mero de cuenta del alumno
	*@param nombre String nombre del alumno
	*@param apellido_p String primer apellido del alumno
	*@param apellido_m String segundo apellido del alumno
	*@param correo String correo electronico del alumno
	*@param edad int edad del alumno
	*@param carrera String carrera que est$aacute; cursando el alumno
	*@param sexo String sexo del alumno
	*@param telefono int telefono del alumno
	*@param fecha_nac int fecha de nacimiento del alumno
 	*/
	public Alumno(String numCuenta, String nombre, String apellido_p, String apellido_m ,
	 String correo, String edad, String carrera, String sexo, String telefono, String fecha_nac){
		this.numCuenta = numCuenta;
		this.nombre = nombre;
		this.apellido_p= apellido_p;
		this.apellido_m= apellido_m;
		this.correo = correo;
		this.edad= edad;
		this.carrera = carrera;
		this.sexo= sexo;
		this.telefono= telefono;
		this.fecha_nac= fecha_nac;
		
	}
	/**
	*M&eacute; para obtener el numero de cuenta
	*@param numCuenta String es el numero de cuenta del alumno
	*@return numCuenta String regresa el numero de cuenta del alumno
	*/
	public String getNumCuenta(){
		return this.numCuenta;
	}
	/**
	*M&eacute; para modificar el numero de cuenta
	*@param numCuenta String nuevo numero de cuenta
	*/
	public void setNumCuenta(String numCuenta){
		this.numCuenta = numCuenta;
	}

	/**
	*M&eacute; para obtener el nombre
	*@param nombre String es el nombre del alumno
	*@return nombre String devuelve el nombre del alumno
	*/
	public String getNombre(){
		return this.nombre;
	}
	/**
	*M&eacute; para modificar el nombre
	*@param nombre String nuevo nombre
	*/
	public void setNombre(String nombre){
		this.nombre = nombre;
	}

	/**
	*M&eacute; para obtener el apellido paterno
	*@param apellido_p String es el primer apellido del alumno
	*@return apellido_p String es el apellido paterno del alumno
	*/
	public String getApellido_p(){
		return this.apellido_p;
	}
	/**
	*M&eacute; para modificar el apellido paterno
	*@param apellido_p String nuevo apellido paterno
	*/
	public void setApellido_p(String apellido_p){
		this.apellido_p = apellido_p;
	}

	/**
	*M&eacute; para obtener el apellido paterno
	*@param apellido_m String es el segundo apellido del alumno
	*/
	public String getApellido_m(){
		return this.apellido_m;
	}
	/**
	*M&eacute; para modificar el apellido paterno
	*@param apellido_m String nuevo apellido materno
	*/
	public void setApellido_m(String apellido_m){
		this.apellido_m = apellido_m;
	}
	/**
	*M&eacute; para obtener el correo del alumno
	*@param apellido_p String es el primer apellido del alumno
	*/
	public String getCorreo(){
		return this.correo;
	}
	/**
	*M&eacute; para modificar el correo del alumno
	*@param correo String nuevo correo del alumno
	*/
	public void setCorreo(String correo){
		this.correo = correo;
	}
	/**
	*M&eacute; para obtener la edad del alumno
	*@param edad int es la edad del alumno
	*/
	public String getEdad(){
		return this.edad;
	}
	/**
	*M&eacute; para modificar la edad del alumno
	*@param edad int nueva edad del alumno
	*/
	public void setEdad(String edad){
		this.edad = edad;
	}
	/**
	*M&eacute; para obtener la carrera que esta cursando el alumno
	*@param edad String la carrera del alumno
	*@return carrera String regresa la carrera que estudia el alumno
	*/
	public String getCarrera(){
		return this.carrera;
	}
	/**
	*M&eacute; para modificar la edad del alumno
	*@param carrera String la nueva carrera del alumno
	*/
	public void setCarrera(String carrera){
		this.carrera = carrera;
	}
	/**
	*M&eacute; para obtener el sexo del alumno
	*@param sexo String es el sexo del alumno
	*@return sexo String regresa el sexo del alumno
	*/
	public String getSexo(){
		return this.sexo;
	}
	/**
	*M&eacute; para modificar la edad del alumno
	*@param sexo Strng nuevo sexo del alumno
	*/
	public void setSexo(String sexo){
		this.sexo = sexo;
	}

	/**
	*M&eacute; para obtener el telefono del alumno
	*@param telefono String es el telefono del alumno
	*@return telefono String regresa el numero telefonico del alumno
	*/
	public String getTelefono(){
		return this.telefono;
	}
	/**
	*M&eacute; para modificar el telefono del alumno
	*@param telefono String el nuevo telefono del alumno
	*/
	public void setTelefono(String telefono){
		this.telefono = telefono;
	}
	/**
	*M&eacute; para obtener la fecha de nacimineto del alumno
	*@param fecha_nac String la nueva fecha de nacimiento del alumno
	*@return fecha_nac String regresa la fecha de nacimineto del alumno
	*/
	public String getFecha_nac(){
		return this.fecha_nac;
	}
	/**
	*M&eacute; para modificar la fecha de nacimiento del alumno
	*@param fecha_nac String la nueva fecha de nacimiento del alumno
	*/
	public void setFecha_nac(String fecha_nac){
		this.fecha_nac = fecha_nac;
	}
	/**
	*M&eacute;todo para saber si es cierto que el alumno estudia ciencias de la computacion o no
	*@param carrera String es la carrera del alumno.
	*@return ccc boolean es el resultado booleano que nos dice si el estudiante estudia ciencias de la computacion.
	*/
	public boolean resultado(String carrera){
		boolean ccc;
		if(carrera.equals("ciencias de la computacion")){
			  ccc = true;
		}
		else{
			ccc = false;
		}
		return ccc;
	}

	/**
	*M&eacute;todo para sacar el CURP del alumno
	*@param alumno Object es el objeto alumno con el cual podemos obtener informacion como su fecha de nacimiento, nombre y apellidos.
	*@return curp.toUpperCase(); String es el CURP del alumno
	*/	
	public String curp(Alumno a){
		String nombre1 = a.getNombre();
		String apellidop = a.getApellido_p();
		String apellidom = a.getApellido_m();
		String nac = a.getFecha_nac();
		String inm = nombre1.substring(0,1);
		String inp = apellidop.substring(0,2);
		String inam = apellidom.substring(0,1);
		String curp = inp + inam + inm+ nac + "HDF" + "KL" + "09";
		return curp.toUpperCase();
	}
	/**
	*Calculadora de edad para punto extra
	*M&eacute;todo para sacar los años del alumno a partir de la fecha de nacimiento
	*@param alumno Object recibimos el objeto alumno del cual se quiere obtener la edad para asi poder sacar el dato de la fecha de nacimiento.
	*@return result String es la edad del alumno.
	*/
	public String CalcuEdad(Alumno a){
		Date d = new Date();
		Calendar c = new GregorianCalendar(); 
		c.setTime(d);

		String dia2, mes2, anio2;

		dia2 = Integer.toString(c.get(Calendar.DATE));
		mes2 = Integer.toString(c.get(Calendar.MONTH));
		anio2 = Integer.toString(c.get(Calendar.YEAR));

		String fecha = a.getFecha_nac();
		String dia = fecha.substring(0,2);
		String mes = fecha.substring(2,4);
		String anio = fecha.substring(4,6);
		int dia1 = Integer.parseInt(dia);
		int mes1 = Integer.parseInt(mes);
		int anio1 = Integer.parseInt(anio) + 1900;
		int diaA = Integer.parseInt(dia2);
		int mesA = Integer.parseInt(mes2);
		int anioA = Integer.parseInt(anio2);
		int rest1 = mesA - mes1;
		int rest2 = diaA - dia1;
		int rest3 = anioA - anio1;
		int rest4 = rest3 -1;
		String result = "";
		
		if(rest1 == 0){
			if(rest2>= 0){
				result = Integer.toString(rest3);

			}
			else{
				result = Integer.toString(rest4);
			}
		}
		if(rest1 > 0){
			 result = Integer.toString(rest3);
		}
		if(rest1 < 0){
			 result = Integer.toString(rest4);
		}

		return result;

	}

	/**
	*toString clase Alumno
	*@return String representacion en cadena del objeto
	*/
	@Override
	public String toString(){
		return "Numero de cuenta: "+this.numCuenta+
			"\nNombre: "+this.nombre+
			"\nApellido paterno:"+this.apellido_p+
			"\nApellido materno: "+this.apellido_m+
			"\nCorreo:"+this.correo+
			"\nEdad: "+this.edad+
			"\nCarrera: "+this.carrera+
			"\nSexo: "+this.sexo+
			"\nTelefono: "+this.telefono+
			"\nFecha de nacimiento: "+ this.fecha_nac;

	}



	public static void main(String[] args) {
		
		Alumno alumno = new Alumno();
		Alumno alumno2 = new Alumno("309199814","Lalo","Miranda","Martinez",
			"mail@mail.com", "17", "ciencias de la computacion", "hombre", "123513513", "110598");
		System.out.println(alumno);//Alumno por Omision
		
		System.out.println(alumno2);
	
		String curp = alumno2.curp(alumno2);
		System.out.println("Tu Curp es :"+ curp);

		boolean ccc = alumno2.resultado(alumno2.getCarrera());
		System.out.println("Estudias actualmente la carrera de computacion : "+ ccc);

		String result = alumno2.CalcuEdad(alumno2);
		System.out.println("La edad del alumno es :"+ result);

		

	}

}