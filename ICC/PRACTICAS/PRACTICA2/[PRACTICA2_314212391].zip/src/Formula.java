public class Formula {
		public static void main(String[] args) {
		double resultado = 0;
		int r = 6;
		int a = 2;
		int b = 3;
		int c = 4;
		int d = 5;
		

		resultado = (float)((30.0)/(3*(r + 34)))-(9*(a+(b*c)))+((3+(d*(2+a)))/(a+(b*d)));

		System.out.println("Con a = 2, b= 3, c = 4, d = 5, r = 6" );
		System.out.println("El resultado de la formula es "+resultado);
	}
}