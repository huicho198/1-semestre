/**
*Clase que convierte medidas de millas a kilometros
*/
public class Millas2Kms {
	
	public static void main(String[] args) {
		double millas = 202;
		double MILLAS_A_KILOMETROS = 1.609;
		double kilometros = millas * MILLAS_A_KILOMETROS;

		
		
		// Asignacion de valor a la variable kilometros
		System.out.println("\t\t***Convertidor millas a kilometros***\n");

		System.out.println("La distancia de Londres a Liverpool es de " + millas +" "+"millas \n"+"que corresponden a"+ " " + kilometros + "kilometros" ); //Completar esta linea
	}
}