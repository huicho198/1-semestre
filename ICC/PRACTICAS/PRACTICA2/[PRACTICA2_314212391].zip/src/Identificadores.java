/**
*Clase de ejemplo de identificadores
*/

public class Identificadores {
	public static void main(String []args){
		double pi = 3.1416;
		int radio = 15;
		double area = pi * (radio * radio);
		String mensaje = "Resultado";
		System.out.println(mensaje + "= "+ area);
	}
}