/**
*Clase que muestra expresiones aritmeticas y booleanas
*/
public class AsignacionCompuesta{
	
	public static void main(String args []){
		int a = 10;
		int b = 20;
		int c = 5;
		int d = 2;
		int resultado1 = 40;
		
		int resultado2 = 10;
		
		int resultado3 = 5;
		
		resultado1 += a + b;

		System.out.println("Resultado 1 = "+resultado1);

		resultado2 *= c * d;

		System.out.println("Resultado 2 = "+resultado2);

		boolean bool_a = true;
		boolean bool_b = false;

		boolean bool_result = false;

		bool_result = !bool_result&& true;

		System.out.println("El resultado de la operacion booleana es: "+bool_result);


	}
}
