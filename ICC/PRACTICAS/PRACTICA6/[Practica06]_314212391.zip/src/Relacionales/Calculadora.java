import java.util.Scanner;
/**
  * Calculadora.java
  * <br>Clase que implementa el metodo main para probar la clase de los
  * numeros racionales
  * @version Marzo de 2012
  */

public class Calculadora{
  public static void main (String[] args){
    Scanner lector = new Scanner(System.in);
    Racional r1;
    Racional r2;
    Racional r3, r4, r5, r6, r7;

    int n1,n2,d1,d2;

    System.out.println("***CALCULADORA DE RACIONALES***\n");
    System.out.println("Vamos a definir dos numeros racionales para trabajar...");
    System.out.println("Dame el primer numerador: ");
    n1 = lector.nextInt();
    System.out.println("Dame el primer denominador: ");
    d1 = lector.nextInt();
    r1 = new Racional(n1,d1);
    System.out.println("Dame el segundo numerador: ");
    n2 = lector.nextInt();
    System.out.println("Dame el segundo denominador: ");
    d2 = lector.nextInt();
    r2 = new Racional(n2,d2);
    System.out.println ("Primer numero racional: " + r1);
    System.out.println ("Segundo numero racional: " + r2);

    if (r1.equals(r2))
     System.out.println ("r1 y r2 son iguales");
    else
     System.out.println ("r1 y r2 no son iguales");

    r3 = r1.reciproco();
    System.out.println ("El reciproco de r1 es: " + r3);

    r4 = r1.suma(r2);
    r5 = r1.resta(r2);
    r6 = r1.multiplica(r2);
    r7 = r1.divide(r2);
    System.out.println ("r1 + r2: " + r4);
    System.out.println ("r1 - r2: " + r5);
    System.out.println ("r1 * r2: " + r6);
    System.out.println ("r1 / r2: " + r7);
 }//Fin main
}//Fin Calculadora

