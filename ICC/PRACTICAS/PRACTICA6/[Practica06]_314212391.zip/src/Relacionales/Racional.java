/**
  * Racional.java
  * <br>Clase que permite representar un numero racional a traves del cociente
  * de dos enteros de la forma p/q
  * @author Luis Alberto Martinez Monroy
  * @version septiembre de 2016
  */

public class Racional {

 //Define aqui los atributos
  private int numerador = 0;
  private int denominador = 0;
 /**
   * Constructor por omision
   * <br>Constructor que permite definir un n&uacute;mero racional valido
   */

 public Racional() {
  this.numerador= 1;
  this.denominador = 1;
  //Coloca aqui el codigo faltante
 }

 /**
   * Constructor que recibe parametros
   * <br>Permite definir un numero racional a partir de un par de enteros
   * @param int el numerador
   * @param int el denominador
   */

 public Racional(int n,int d){

  this.numerador = n;
  this.denominador = d;

 }

 /**
   * Metodo que permite establecer el valor del numerador
   * @param int parametro de tipo entero
   */

 public void hhhh(int n){
   this.numerador = n;
 }

 /**
   * Metodo que permite establecer el valor del denominador
   * @param int parametro de tipo entero
   */

 public void establecerDen(int d){
   this.denominador = d;
 }

 /**
   * Metodo que regresa el numerador del numero racional
   * @return int el valor del numerador
   */

 public int obtenerNum(){
  return this.numerador;
 }

 /**
   * Metodo que regresa el denominador del numero racional
   * @return int el valor del denominador
   */

 public int obtenerDen(){
  return this.denominador;
 }

 /**
   * Metodo de regresa el reciproco del numero racional
   * @return Racional el reciproco del numero racional
   */

 public Racional reciproco(){
  int n = obtenerNum();
  int d =obtenerDen();
  Racional a = new Racional(d,n);
  return a;
 }

 /**
   * Metodo que suma el racional actual con otro pasado como parametro
   * @param Racional el racional con el que se realizara la operacion
   * @return Racional el racional resultante de la suma
   */
 public Racional suma (Racional r2){
  int n1 = this.numerador;
  int d1 = this.denominador;
  int n2 = r2.obtenerNum();
  int d2 = r2.obtenerDen();
  int ns, ds;
  int nss1, nss2;
   if(d1==d2){
     ns = n1+n2;
     ds = d1;
   }
   else{
     ds =d1 * d2;
     nss1 = (ds/d1)*n1;
     nss2 = (ds/d2)*n2;
     ns = nss1+ nss2;
   }

Racional a = new Racional(ns, ds);
return a;
 }

 /**
   * Metodo que resta el racional actual con otro pasado como parametro
   * @param Racional el racional con el que se realizara la operacion
   * @return Racional el racional resultante de la resta
   */
 public Racional resta (Racional r2){
  int n1 = this.numerador;
  int d1 = this.denominador;
  int n2 = r2.obtenerNum();
  int d2 = r2.obtenerDen();
  int dr, nr;
   if(d1==d2){
     nr = n1-n2;
     dr = d1;
   }
   else{
     dr =d1 * d2;
    int nrr1 = (dr/d1)*n1;
    int nrr2 = (dr/d2)*n2;
     nr = nrr1-nrr2;
   }

Racional a = new Racional(nr, dr);
return a;
 }

 /**
   * Metodo que multiplica el racional actual con otro pasado como parametro
   * @param Racional el racional con el que se realizara la operacion
   * @return Racional - el racional resultante de la multiplicacion
   */

 public Racional multiplica (Racional r2){
 
 int n1 = this.numerador;
  int d1 = this.denominador;
  int n2 = r2.obtenerNum();
  int d2 = r2.obtenerDen();
  int nm = n1* n2;
  int dm = d1*d2;
  Racional a = new Racional(nm, dm);
  return a;
 }

 /**
   * Metodo que divide el racional actual con otro pasado como parametro
   * @param Racional el racional con el que se realizara la operacion
   * @return Racional el racional resultante de la division
   */

 public Racional divide (Racional r2){
  int n1 = this.numerador;
  int d1 = this.denominador;
  int n2 = r2.obtenerNum();
  int d2 = r2.obtenerDen();
  int nd = n1*d2;
  int dd = d1*n2;
  Racional a = new Racional(nd, dd);
  return a;
 }

 /**
   * Metodo que determina si dos Racionales son iguales
   * @param Object un objeto racional
   * @return boolean true si son iguales, false en caso contrario
   */

 public boolean equals(Racional r2){
  int n1 = this.numerador;
  int d1 = this.denominador;
  int n2 = r2.obtenerNum();
  int d2 = r2.obtenerDen();
  boolean a;
  if(n1 == n2 && d1 == d2){
    a= true;
  }
  else{
    a=false;
  }
  return a;
 }

 /**
   * M&eacute;todo que permite imprimir un racional como una cadena de caracteres
   * @return String el n&uacute;mero racional en formato p/q
   */

 public String toString (){
  return  
          this.numerador+"/"+ this.denominador;

 }
}//Fin Racional
