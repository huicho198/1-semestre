/**
* Programa que muestra los n primeros cubos utilizando la propiedad
* descubierta po Nicomaco.
* @author Martinez Monroy Luis Alberto
*/
import java.util.Scanner;

public class CubosNicomaco {

  public static void main(String[] stx) {
    Scanner lector = new Scanner(System.in);
    System.out.println("Introduce el valor de n:");
    int n = lector.nextInt();
    int m = 1;
    int p = 0;
    for(int i = 1; i<=n; i++){
    	p = 0;
    	if(i==1){
    		System.out.println("1^3 = 1 = 1");
    	}
    	else{
    		System.out.print(i+"^3 =");
    		
    		for(int k =1; k<=i; k++){
    			if(k==1){
    				m+=2;
    				p+=m;
    				System.out.print(m + "+");
    			}
    			if(k==i){
    				m+=2;
    				p+=m;
    				System.out.println(m + "="+ p);
    			}
    			if(k!=1 && k!=i){
    				m+=2;
    				p+=m;
    				System.out.print(m + "+");
    			}
    		}
    	}
    }
    
    
    
    lector.close();
  }
}
