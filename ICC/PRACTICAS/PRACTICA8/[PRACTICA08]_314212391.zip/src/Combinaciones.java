/**
 * Programa que calcula el coeficiente Binomial C(n,k).
 * @author Martinez Monroy Luis Alberto
 */
import java.util.Scanner;

public class Combinaciones {


  public static void main(String[] stx) {
    Scanner lector = new Scanner(System.in);
    System.out.println("Introduce el valor de n:");
    int n = lector.nextInt();
    System.out.println("Introduce el valor de k:");
    int k = lector.nextInt();
    int coeficiente = 0;
    int r = n-k;

    for(int i = n-1; i>0; i--){
        n*= i;
    }

    System.out.println(n);
    for(int i = k-1; i>0; i--){
        k*= i;
    }

    System.out.println(k);
    if(r==1){
     r =1;
    }
    if(r!= 1){
        for(int i = r-1; i>0; i--){
        r*= i;
        }
    }

    System.out.println(r);
    coeficiente = n/(r*k);

 

    //Imprime la formula empleada
    System.out.println("         n!      ");
    System.out.println("     ----------- = "+coeficiente);
    System.out.println("      k!*(n-k)!  \n ");
    lector.close();
  }
}
